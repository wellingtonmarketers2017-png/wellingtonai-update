# TN IGS seven-programme and City AI update — 2026

This is an ADDITIVE update for the Git-connected Next.js Wellington AI project. Copy the two files under `public/` and two optional App Router files under `app/` into the existing source repository. Do not replace the project root or existing pages. Review changes in a feature-branch PR, verify preview and CI, then merge.

Routes after deployment: `/roadmap-2036`, `/city-ai-rating`; static fallback `/roadmap-2036.html`, `/city-ai-rating.html`. Add navigation entries manually in the existing app. This package does not automatically modify the existing City Indicator tab; integrate/link the city page into that tab and remove its old `Flood AI` entry in the repository source.

Part IV: target-calibrated 2027–2036 GVA/GSDP and capital roadmap from TN IGS reference report. Part V: ₹198,000 crore ten-year benefit ledger, 7 programmes (6 revenue projects + TN IGS); illustrative editable allocation shares default 12/18/12/10/22/12/14%, NOT in source report. Part VI: 2036 $1.5 trillion GSDP target and exchange rate; programme share uses Part IV GSDP and does not add Part V.

City rating: `Flood AI` excluded; ThamesAI river floods, UrbanAI urban drainage remain distinct. PlantationAI and HydelAI added as conditional, confidence-adjusted suitability scores with neutral input placeholders. No measured city ratings claimed.

Source: TN IGS - REFERENCE REPORT (1).pdf, 2 Nov 2026; https://wellingtonai.in/ (PlantationAI, HydelAI, ThamesAI, UrbanAI descriptions). Neither production app nor its Git repository was changed.


## City AI factors chart update (19 Nov 2026)
`public/city-ai-rating.html` now shows a seven-model horizontal suitability chart and an immediately following compact table of model-specific factors and evidence requirements for TradeAI, ThamesAI, UrbanAI, TransitAI, PlantationAI, HydelAI and AirlineAI. Flood AI remains excluded. Technical inputs for the four existing models remain editable; the three newly listed models begin with neutral placeholder scores (not city measurements). A common five-dimension weighting is explained, but not asserted to be calculated from actual city data. City selection is a scenario label and does not load observations. No live deployment or existing City Indicator source modification is included.

### AirlineAI city rating update
AirlineAI now has editable passenger/business demand (40%), airport/route connectivity (30%) and operating/economic feasibility (30%) factors, multiplied by the shared evidence-confidence factor. Initial inputs are illustrative 50/100 and do not automatically change with the city selector. Evaluate airport catchment and regional connectivity, not just airports within city limits.
